import mysql.connector
from datetime import datetime
import time
import logging
from config import *
from funzioni import *

LOG_FILE = "LOG/logfile_Archiviatore.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, mode='a'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

test_mode = True  # Settare False per produzione
already_executed = False   # Flag per evitare che l'elaborazione venga eseguita più volte nello stesso intervallo

def main():
    logger.info("Avvio monitoraggio per eliminare dati dal DB vecchi (Ctrl + C per uscire)...")

    global already_executed

    if test_mode:
        now = datetime(2026, 7, 1, 0, 0)
    else:
        now = datetime.now()
    
    while True:
        try:
            # Se è il primo giorno del mese
            if now.day == 1 and not already_executed:
                logger.info(f"[{now}] Inizio elaborazione...")

                # Recupera l'intervallo di date da elaborare e informazioni di mese e anno
                start, end, month, year = get_date_range(now)

                try:
                    # Connessione al database usando i parametri di configurazione
                    conn = mysql.connector.connect(**DB_CONFIG)
                    cursor = conn.cursor()

                    # Per ogni tabella/configurazione definita in STRUCTURE, processa i dati per l'intervallo specificato
                    for name, conf in STRUCTURE.items():
                        process_table(cursor, conf, start, end, month, year)
                        conn.commit()  # Salva le modifiche sul database

                    cursor.close()  # Chiude il cursore
                    conn.close()    # Chiude la connessione
                    logger.info("✅ Completato.")

                except Exception as e:
                    logger.error(f"❌ Errore: {e}")

                already_executed = True  # Imposta il flag per non rieseguire l'elaborazione nello stesso giorno

            # Se non è il primo giorno del mese, resetta il flag per poter rieseguire il prossimo mese
            if now.day != 1:
                already_executed = False

            # Se siamo in modalità test, esci subito dal ciclo dopo una singola iterazione
            if test_mode:
                break

            # Attendi
            time.sleep(3600)
            
        except KeyboardInterrupt:
            logger.info("⏹ Interrotto manualmente. Uscita dal programma.")
            break

if __name__ == "__main__":
    main()
