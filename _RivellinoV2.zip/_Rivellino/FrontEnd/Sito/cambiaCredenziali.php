<?php
$codice = $_POST['codice'] ?? null;
$nuovoUser = $_POST['nuovoUser'] ?? null;
$nuovaPw = $_POST['nuovaPw'] ?? null;
$confermaPw = $_POST['confermaPw'] ?? null;

$conn = new mysqli("localhost", "root", "", "rivellino");
if ($conn->connect_error) die("Errore connessione DB");

if ($codice && !$nuovoUser) {
    // FASE 1: Verifica OTP
    $stmt = $conn->prepare("SELECT id, scadenza, usato FROM otp_codici WHERE codice = ? ORDER BY id DESC LIMIT 1");
    $stmt->bind_param("s", $codice);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows === 0) {
        echo "Codice non valido.";
		
    } else {
        $row = $res->fetch_assoc();
        $now = date("Y-m-d H:i:s");

        if ($row['usato']) {
            echo "Codice già usato.";
        } elseif ($row['scadenza'] < $now) {
            echo "Codice scaduto.";
        } else {
            // Segna il codice come usato
            $stmt = $conn->prepare("UPDATE otp_codici SET usato = 1 WHERE id = ?");
            $stmt->bind_param("i", $row['id']);
            $stmt->execute();
            $stmt->close();

            // Mostra il form per il cambio credenziali
            echo '<form action="cambiaCredenziali.php" method="POST">
                    <input type="hidden" name="codice" value="'.htmlspecialchars($codice).'">
                    <label for="nuovoUser">Nuovo username:</label>
                    <input type="text" name="nuovoUser" required><br>

                    <label for="nuovaPw">Nuova password:</label>
                    <input type="password" name="nuovaPw" required><br>

                    <label for="confermaPw">Conferma password:</label>
                    <input type="password" name="confermaPw" required><br>

                    <button type="submit">Salva modifiche</button>
                  </form>';
        }
    }

} elseif ($nuovoUser && $nuovaPw && $confermaPw) {
    // FASE 2: Validazioni input
    if (strlen($nuovoUser) < 4) {
        echo "Username troppo corto. Minimo 4 caratteri.";
        exit;
    }

    if (strlen($nuovaPw) < 8) {
        echo "Password troppo corta. Minimo 8 caratteri.";
        exit;
    }

    if ($nuovaPw !== $confermaPw) {
        echo "Le password non coincidono.";
        exit;
    }

    // Recupera la vecchia password
    $query = $conn->query("SELECT passwordUtente FROM utente WHERE id = 0");
    if ($query && $query->num_rows > 0) {
        $vecchia = $query->fetch_assoc();

        if (password_verify($nuovaPw, $vecchia['passwordUtente'])) {
            echo "La nuova password non può essere uguale alla precedente.";
            exit;
        }
    }

    // Salva nuove credenziali
    $hashPw = password_hash($nuovaPw, PASSWORD_BCRYPT);
    $stmt = $conn->prepare("UPDATE utente SET userUtente = ?, passwordUtente = ? WHERE id = 0");
    $stmt->bind_param("ss", $nuovoUser, $hashPw);
    $stmt->execute();

    echo $stmt->affected_rows > 0 ? "Credenziali aggiornate." : "Errore o nessuna modifica.";
    $stmt->close();

} else {
    echo "Richiesta non valida.";
}

$conn->close();
?>
