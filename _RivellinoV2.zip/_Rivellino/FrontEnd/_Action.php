<?php
require_once '_Function.php';

$ip = $_SERVER['HTTP_HOST'];
$azione = $_POST['action'] ?? '';

switch ($azione) {
    case 'login':
        $utente = trim($_POST['user'] ?? '');
        $password = $_POST['pw'] ?? '';

        if (empty($utente) || empty($password)) {
            header("Location: http://$ip?error=dati_mancanti");
            exit();
        }

        Login($utente, $password, $ip);
        break;

    case 'cambiaCredenziali':
        ProceduraOTP($ip);
        break;

    case 'verificaCredenziali':
        ValidaOTP($ip, $_POST['codice'] ?? '');
        break;

    case 'modificaCredenziali':
        CambiaCredenziali($ip, $_POST);
        break;
		
	case 'annulla':
		header("Location: http://$ip");
        exit();

    default:
        header("Location: http://$ip?error=azione_non_valida");
        exit();
}
?>
