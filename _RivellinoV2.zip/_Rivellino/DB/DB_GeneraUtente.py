import mysql.connector
import bcrypt
import getpass

#Configurazioni del DB
DB_HOST = "localhost"
DB_USER = "remoteUser"
DB_PASSWORD = "!rivellino!RIVELLINO!"
DB_NAME = "rivellino"

def get_db_connection():
    return mysql.connector.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME
    )

def crea_utente(id_utente, username, password):
    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO utente (id, userUtente, passwordUtente) VALUES (%s, %s, %s) "
        "ON DUPLICATE KEY UPDATE userUtente=%s, passwordUtente=%s",
        (id_utente, username, hashed.decode(), username, hashed.decode())
    )
    conn.commit()
    cursor.close()
    conn.close()
    print(f"Utente con id={id_utente} creato/aggiornato con successo.")

if __name__ == "__main__":
    print("=== Creazione utente per tabella 'utente' ===")
    id_utente = int(input("ID utente (0=web, 1=normale, 2=admin): "))
    username = input("Username: ")
    password = getpass.getpass("Password: ")
    crea_utente(id_utente, username, password)