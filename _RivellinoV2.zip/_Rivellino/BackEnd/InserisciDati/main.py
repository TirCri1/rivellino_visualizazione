import time
import threading
import logging
import signal
import sys
from funzioni import insert, update_battery_charger

# --- CONFIGURAZIONE LOGGING ---
LOG_FILE = "LOG/logfile_Caricatore.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(threadName)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, mode='a'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# --- COSTANTI ---
INTERVALS = {
    "temp": 10,
    "umid": 10,
    "ariaCO": 10,
    "ariaNO2": 10,
    "vibrazione": 1,
    "allagamento": 5,
    "alimentazione": 15
}

stop_event = threading.Event()
threads = []

def start_thread(sensor_type: str, interval: int):
    """
    Avvia un thread che esegue periodicamente l'inserimento dati per il sensore specificato.
    """
    def loop():
        logger.info(f"Thread avviato per '{sensor_type}' ogni {interval}s")
        while not stop_event.is_set():
            try:
                if sensor_type == "alimentazione":
                    update_battery_charger(sensor_type)
                else:
                    insert(sensor_type)
            except Exception as e:
                logger.error(f"Errore nel thread '{sensor_type}': {e}", exc_info=True)
            if stop_event.wait(interval):
                break
        logger.info(f"Thread '{sensor_type}' terminato.")

    thread = threading.Thread(target=loop, name=f"Thread-{sensor_type}", daemon=True)
    thread.start()
    threads.append(thread)

def signal_handler(sig, frame):
    logger.info(f"Ricevuto segnale {sig}. Arresto in corso...")
    stop_event.set()

def main():
    # Gestione segnali per shutdown pulito
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    logger.info("Avvio InserisciDati...")
    for sensor_type, interval in INTERVALS.items():
        start_thread(sensor_type, interval)

    try:
        while not stop_event.is_set():
            time.sleep(1)
    except Exception as e:
        logger.error(f"Errore nel main loop: {e}", exc_info=True)
    finally:
        logger.info("Chiusura dei thread in corso...")
        stop_event.set()
        for t in threads:
            t.join()
        logger.info("Terminato correttamente.")

if __name__ == "__main__":
    main()
