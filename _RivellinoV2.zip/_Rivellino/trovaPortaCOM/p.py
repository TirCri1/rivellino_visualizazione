import serial
import serial.tools.list_ports
import time

def trova_tutte_le_porte():
    return serial.tools.list_ports.comports()

def prova_lettura_su_porte():
    porte = trova_tutte_le_porte()

    if not porte:
        print("⚠️ Nessuna porta seriale trovata.")
        return

    for porta in porte:
        print(f"\n🔍 Test porta: {porta.device} ({porta.description})")
        try:
            # Prova ad aprire la porta
            ser = serial.Serial(porta.device, 9600, timeout=2)
            time.sleep(2)  # Attendi per permettere al dispositivo di inizializzarsi

            # Leggi i dati (max 5 righe)
            for _ in range(5):
                if ser.in_waiting:
                    dato = ser.readline().decode('utf-8', errors='ignore').strip()
                    print(f"📥 Dato ricevuto da {porta.device}: {dato}")
                else:
                    print(f"...nessun dato da {porta.device}")
                time.sleep(1)

            ser.close()
        except (serial.SerialException, OSError) as e:
            print(f"❌ Errore su {porta.device}: {e}")

prova_lettura_su_porte()
