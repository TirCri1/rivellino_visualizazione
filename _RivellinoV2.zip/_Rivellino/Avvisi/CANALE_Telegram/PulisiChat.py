from Funzioni import save_message_id

i=100

while(i<1000):
    i += 1
    save_message_id(i)
