import time
import logging
import signal
import sys
from datetime import datetime, timedelta
from Config import *
from Funzioni import *

# --- CONFIGURAZIONE LOGGING ---
LOG_FILE = "LOG/logfile_telegramChat.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, mode='a'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

def stop_handler(signum, frame):
    logger.info("🛑 Interruzione ricevuta. Chiusura canale...")
    sys.exit(0)

def main():
    """
    Ciclo principale per il monitoraggio e l'invio di notifiche critiche su Telegram.
    """
    signal.signal(signal.SIGINT, stop_handler)
    signal.signal(signal.SIGTERM, stop_handler)

    events = [False, False, False]
    message = ["", "", ""]
    last = [None, None, None, None]
    resend = [None, None, None]

    lastHour = {
        "allag": datetime.now() - timedelta(seconds=interval["allag"]),
        "batt": datetime.now() - timedelta(seconds=interval["batt"]),
        "vibr": datetime.now() - timedelta(seconds=interval["vibr"])
    }

    logger.info("💬 Chat avviato. Premi Ctrl+C per terminare.")
    try:
        while True:
            events = [False, False, False]
            now = datetime.now()

            for tipo in ["allag", "batt", "vibr"]:
                if (now - lastHour[tipo]).total_seconds() >= interval[tipo]:
                    verifica(tipo, events, message, last)
                    lastHour[tipo] = now

            for i in range(len(resend)):
                if resend[i] is not None and resend[i] <= now - timedelta(seconds=interval['resend']):
                    events[i] = True

            for i in range(len(events)):
                if events[i]:
                    response = send_message(TOKEN, CHAT_ID, message[i])
                    logger.info(f"Messaggio inviato: {response}")
                    resend[i] = now

            time.sleep(1)

    except Exception as e:
        logger.error(f"Errore nel ciclo principale: {e}", exc_info=True)
    finally:
        logger.info("Chiusura canale Telegram.")

if __name__ == "__main__":
    main()
