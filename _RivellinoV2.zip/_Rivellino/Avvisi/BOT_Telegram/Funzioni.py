from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import ContextTypes
import asyncio
import requests
import json
import logging
import mysql.connector
import bcrypt

from Config import *

logger = logging.getLogger(__name__)

# ====== VARIABILI STATO ======
stato_utenti = {}
dati_utente = {}
messaggi_utente = {}

# ====== FUNZIONI DB ======
def get_db_connection():
    return mysql.connector.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME
    )

def get_user_by_id(user_id):
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT userUtente, passwordUtente FROM utente WHERE id = %s", (user_id,))
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    return result

def update_user_credentials(user_id, new_username, new_password):
    hashed = bcrypt.hashpw(new_password.encode(), bcrypt.gensalt())
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE utente SET userUtente=%s, passwordUtente=%s WHERE id=%s",
        (new_username, hashed.decode(), user_id)
    )
    conn.commit()
    cursor.close()
    conn.close()

def verify_password(password, hashed):
    return bcrypt.checkpw(password.encode(), hashed.encode())

# ====== FUNZIONI DI UTILITÀ ======
async def invia_e_memorizza(update, chat_id, testo, reply_markup=None):
    msg = await update.message.reply_text(testo, reply_markup=reply_markup)
    messaggi_utente.setdefault(chat_id, []).append(msg.message_id)
    return msg

async def pulisci_chat_dopo_delay(context: ContextTypes.DEFAULT_TYPE, chat_id: int, time):
    logger.info(f"[🕒] Inizio sleep per {time} secondi per la chat {chat_id}")
    await asyncio.sleep(time)
    for msg_id in messaggi_utente.get(chat_id, []):
        try:
            await context.bot.delete_message(chat_id=chat_id, message_id=msg_id)
        except Exception as e:
            logger.warning(f"[⚠️] Errore cancellazione messaggio {msg_id}: {e}")
    messaggi_utente.pop(chat_id, None)

async def elimina_messaggi_canale(update, chat_id):
    try:
        with open(MESSAGES_FILE, 'r') as f:
            message_ids = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        logger.warning("[⚠️] File messaggi non trovato o vuoto.")
        await invia_e_memorizza(update, chat_id, "Messaggi non trovati o già eliminati.")
        return

    for msg_id in message_ids:
        try:
            response = requests.post(
                f'https://api.telegram.org/bot{TOKEN}/deleteMessage',
                data={'chat_id': CHAT_ID, 'message_id': msg_id}
            )
            if response.ok and response.json().get("ok"):
                logger.info(f"[✓] Messaggio {msg_id} eliminato.")
            else:
                logger.warning(f"[X] Errore eliminazione {msg_id}: {response.text}")
        except Exception as e:
            logger.error(f"[X] Errore richiesta eliminazione {msg_id}: {e}")

    with open(MESSAGES_FILE, 'w') as f:
        f.write('[]')
    logger.info("[✅] Tutti i messaggi gestiti ed eliminati.")
    await invia_e_memorizza(update, chat_id, "Messaggi delle ultime 48 ore eliminati con successo")

# ====== /start ======
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    stato_utenti[chat_id] = "attesa_username"
    dati_utente[chat_id] = {}
    messaggi_utente[chat_id] = [update.message.message_id]

    await invia_e_memorizza(update, chat_id, "Benvenuto!")
    await invia_e_memorizza(update, chat_id, "Inserisci il tuo username:")

# ====== Gestione messaggi ======
async def gestisci_messaggi(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    user = update.effective_user
    testo = update.message.text
    messaggi_utente.setdefault(chat_id, []).append(update.message.message_id)

    stato = stato_utenti.get(chat_id)
    if not stato:
        await invia_e_memorizza(update, chat_id, "Per iniziare, usa /start")
        return

    # ====== Inserimento Username ======
    if stato == "attesa_username":
        dati_utente[chat_id]["username"] = testo
        stato_utenti[chat_id] = "attesa_password"
        await invia_e_memorizza(update, chat_id, "Ora inserisci la password:")
        return

    # ====== Inserimento Password ======
    elif stato == "attesa_password":
        dati_utente[chat_id]["password"] = testo
        username = dati_utente[chat_id]["username"]
        password = dati_utente[chat_id]["password"]

        # id=1: utente normale, id=2: admin
        utente_normale = get_user_by_id(1)
        utente_admin = get_user_by_id(2)

        if utente_normale and username == utente_normale["userUtente"] and verify_password(password, utente_normale["passwordUtente"]):
            await invia_e_memorizza(update, chat_id, f"✅ Accesso consentito! Ecco il link: {LINK_CANALI_PRIVATO}")
            logger.info(f"[✅ LOGIN UTENTE] @{user.username or 'N/A'} - {user.full_name or 'N/A'}")
            asyncio.create_task(pulisci_chat_dopo_delay(context, chat_id, time=CLEANUP_DELAY_SECONDS_CHAT))
            stato_utenti.pop(chat_id, None)
            dati_utente.pop(chat_id, None)
            return

        elif utente_admin and username == utente_admin["userUtente"] and verify_password(password, utente_admin["passwordUtente"]):
            keyboard = [
                ["🧹 Elimina messaggi canale"],
                ["🔑 Cambia credenziali utente", "🔑 Cambia credenziali admin"],
                ["❌ Esci"]
            ]
            await invia_e_memorizza(update, chat_id, "✅ Accesso ADMIN. Scegli un'operazione:",
                                    reply_markup=ReplyKeyboardMarkup(keyboard, resize_keyboard=True))
            stato_utenti[chat_id] = "menu_admin"
            logger.info(f"[🔐 LOGIN ADMIN] {user.username}")
            return

        else:
            await invia_e_memorizza(update, chat_id, "❌ Username o password errati.")
            asyncio.create_task(pulisci_chat_dopo_delay(context, chat_id, time=CLEANUP_DELAY_SECONDS_ERROR))
            stato_utenti.pop(chat_id, None)
            dati_utente.pop(chat_id, None)
            return

    # ====== Menu Admin ======
    elif stato == "menu_admin":
        if testo == "🧹 Elimina messaggi canale":
            await invia_e_memorizza(update, chat_id, "🔄 Pulizia in corso...")
            await elimina_messaggi_canale(update, chat_id)
            return

        elif testo == "🔑 Cambia credenziali utente":
            stato_utenti[chat_id] = "cambia_username_normale"
            await invia_e_memorizza(update, chat_id, "Inserisci il nuovo username per l'accesso normale:")
            return

        elif testo == "🔑 Cambia credenziali admin":
            stato_utenti[chat_id] = "cambia_username_admin"
            await invia_e_memorizza(update, chat_id, "Inserisci il nuovo username per l'accesso admin:")
            return

        elif testo == "❌ Esci":
            await invia_e_memorizza(update, chat_id, "🔒 Uscita dalla modalità admin. Tutti i messaggi saranno eliminati.")
            stato_utenti.pop(chat_id, None)
            dati_utente.pop(chat_id, None)
            asyncio.create_task(pulisci_chat_dopo_delay(context, chat_id, time=CLEANUP_DELAY_SECONDS_EXIT))
            return

        else:
            await invia_e_memorizza(update, chat_id, "❓ Comando non riconosciuto. Usa uno dei pulsanti disponibili.")
            return

    # ====== Cambio credenziali utente normale ======
    elif stato == "cambia_username_normale":
        dati_utente[chat_id]["nuovo_username"] = testo
        stato_utenti[chat_id] = "cambia_password_normale"
        await invia_e_memorizza(update, chat_id, "Inserisci la nuova password per l'accesso normale:")
        return

    elif stato == "cambia_password_normale":
        nuovo_username = dati_utente[chat_id]["nuovo_username"]
        nuova_password = testo
        update_user_credentials(1, nuovo_username, nuova_password)
        await invia_e_memorizza(update, chat_id, "✅ Credenziali utente aggiornate.")
        stato_utenti[chat_id] = "menu_admin"
        return

    # ====== Cambio credenziali admin ======
    elif stato == "cambia_username_admin":
        dati_utente[chat_id]["nuovo_username"] = testo
        stato_utenti[chat_id] = "cambia_password_admin"
        await invia_e_memorizza(update, chat_id, "Inserisci la nuova password per l'accesso admin:")
        return

    elif stato == "cambia_password_admin":
        nuovo_username = dati_utente[chat_id]["nuovo_username"]
        nuova_password = testo
        update_user_credentials(2, nuovo_username, nuova_password)
        await invia_e_memorizza(update, chat_id, "✅ Credenziali admin aggiornate.")
        stato_utenti[chat_id] = "menu_admin"
        return