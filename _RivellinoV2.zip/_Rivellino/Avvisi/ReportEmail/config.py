PATH = "Avvisi/ReportEmail/Report/"

# Configurazione dell'email
mittente = "tiranti1cristian@gmail.com"
destinatario = "tiranti1cristian@gmail.com"
oggetto = "Report mensile dati Rivellino"
contenuto = "In allegato trovi il report mensile con i dati dei sensori del museo."

#Configurazioni del DB
DB_CONFIG = {
    "host": "192.168.1.90",
    #"host": "10.10.60.186",
    "user": "remoteUser",
    "password": "!rivellino!RIVELLINO!",
    "database": "rivellino"
}
