import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from fpdf import FPDF
import os
import mysql.connector
import logging
from config import *
import calendar

logger = logging.getLogger(__name__)

def datiRep(mese):
    """
    Estrae i dati aggregati dal database per il report mensile.
    """
    val_T, val_U, val_Co, val_No2, val_A, val_V = [], [], [], [], [], []

    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor()

        queries = [
            ("temperatura", "valore", val_T),
            ("umidita", "valore", val_U),
        ]

        for tabella, campo, lista in queries:
            cursor.execute(f"""
                SELECT AVG({campo}), MIN({campo}), MAX({campo}) 
                FROM {tabella} 
                WHERE MONTH(Data) = %s
            """, (mese,))
            result = cursor.fetchone()
            lista += [f"{v:.2f}" if v is not None else "Nessun dato" for v in result]

        # CO
        cursor.execute("""
            SELECT AVG(ValoreCo), MIN(ValoreCo), MAX(ValoreCo) 
            FROM qualita 
            WHERE MONTH(Data) = %s AND NameSensore = 'SensQualitàAria1'
        """, (mese,))
        val_Co += [f"{v:.2f}" if v is not None else "Nessun dato" for v in cursor.fetchone()]

        # NO2
        cursor.execute("""
            SELECT AVG(ValoreNo2), MIN(ValoreNo2), MAX(ValoreNo2) 
            FROM qualita 
            WHERE MONTH(Data) = %s AND NameSensore = 'SensQualitàAria2'
        """, (mese,))
        val_No2 += [f"{v:.2f}" if v is not None else "Nessun dato" for v in cursor.fetchone()]

        # Allagamenti
        cursor.execute("SELECT Data, Ora FROM allagamento WHERE MONTH(Data) = %s", (mese,))
        allagamenti = [f"{row[0]} {row[1]}" for row in cursor.fetchall()]
        val_A += allagamenti if allagamenti else ["Nessun allagamento registrato"]

        # Vibrazioni
        cursor.execute("SELECT Data, Ora FROM vibrazione WHERE MONTH(Data) = %s", (mese,))
        vibrazioni = [f"{row[0]} {row[1]}" for row in cursor.fetchall()]
        val_V += vibrazioni if vibrazioni else ["Nessuna vibrazione registrata"]

        cursor.close()
        conn.close()

    except mysql.connector.Error as err:
        logger.error(f"[ERRORE DB] {err}")
        return None

    return [val_T, val_U, val_Co, val_No2, val_A, val_V]

def report(val, mese):
    """
    Genera il PDF del report mensile.
    """
    pdf = FPDF()
    pdf.add_page()

    try:
        pdf.image('Avvisi/ReportEmail/logo_rivellino.PNG', 4, 4, 50)
    except Exception as e:
        logger.warning(f"Errore nel caricamento del logo: {e}")

    nome_mese = calendar.month_name[mese]
    pdf.set_font('Arial', 'B', 20)
    pdf.cell(0, 15, f'Report del mese di {nome_mese}', 0, 1, 'C')
    pdf.ln(10)
    pdf.set_font('Arial', '', 14)

    blocchi = [
        ("Sensori temperatura", val[0], "°C"),
        ("Sensori umidità", val[1], "%"),
        ("Sensori qualità (CO)", val[2], "ppm"),
        ("Sensori qualità (NO2)", val[3], "ppm"),
    ]

    for titolo, dati, unita in blocchi:
        pdf.set_font('Arial', 'B', 14)
        pdf.cell(0, 10, f"--- {titolo} ---", 0, 1)
        pdf.set_font('Arial', '', 12)
        if "Nessun dato" in dati:
            pdf.cell(0, 10, "  - Nessun dato disponibile", 0, 1)
        else:
            pdf.cell(0, 10, f"  - Media: {dati[0]} {unita}", 0, 1)
            pdf.cell(0, 10, f"  - Min: {dati[1]} {unita}", 0, 1)
            pdf.cell(0, 10, f"  - Max: {dati[2]} {unita}", 0, 1)

    pdf.set_font('Arial', 'B', 14)
    pdf.cell(0, 10, "--- Sensori allagamenti ---", 0, 1)
    pdf.set_font('Arial', '', 12)
    for evento in val[4]:
        pdf.cell(0, 10, f"  - Allagamento rilevato il {evento}", 0, 1)

    pdf.set_font('Arial', 'B', 14)
    pdf.cell(0, 10, "--- Sensori vibrazioni ---", 0, 1)
    pdf.set_font('Arial', '', 12)
    for evento in val[5]:
        pdf.cell(0, 10, f"  - Vibrazione rilevata il {evento}", 0, 1)

    fileName = f"report_{mese}.pdf"
    file = os.path.join(PATH, fileName)
    pdf.output(file)
    logger.info(f"📄 PDF creato con successo: {fileName}")
    return file

def sendemail(mittente, destinatario, oggetto, contenuto, percorso_allegato):
    """
    Invia una email con allegato (PDF report).
    """
    try:
        messaggio = MIMEMultipart()
        messaggio["From"] = mittente
        messaggio["To"] = destinatario
        messaggio["Subject"] = oggetto
        messaggio.attach(MIMEText(contenuto, "plain"))

        if percorso_allegato and os.path.exists(percorso_allegato):
            with open(percorso_allegato, "rb") as attachment:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(attachment.read())
            encoders.encode_base64(part)
            part.add_header(
                'Content-Disposition',
                f'attachment; filename= {os.path.basename(percorso_allegato)}'
            )
            messaggio.attach(part)
            logger.info(f"📎 Allegato aggiunto: {percorso_allegato}")

        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        password_app = os.environ.get("EMAIL_APP_PASSWORD", "dkfp phwc bspb mjzk")  # Da proteggere in ambiente reale
        server.login(mittente, password_app)
        server.sendmail(mittente, destinatario, messaggio.as_string())
        server.quit()
        logger.info("📧 Email inviata con successo!")

    except Exception as e:
        logger.error(f"❌ Errore invio email: {e}")