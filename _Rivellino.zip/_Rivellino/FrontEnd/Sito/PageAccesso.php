<?php
// <-- PHPMailer namespace e autoload -->
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

$azione = $_POST['action'] ?? '';
$ip = "192.168.1.90";

if ($azione === 'login') {
    $utente = trim($_POST['user'] ?? '');
    $password = $_POST['pw'] ?? '';

    if (empty($utente) || empty($password)) {
        header("Location: http://$ip?error=input");
        exit();
    }

    $conn = new mysqli("localhost", "root", "", "rivellino");
    if ($conn->connect_error) {
        header("Location: http://$ip?error=connessione");
        exit();
    }

    $stmt = $conn->prepare("SELECT passwordUtente FROM Utente WHERE userUtente = ?");
    $stmt->bind_param("s", $utente);
    $stmt->execute();
    $ris = $stmt->get_result();

    if ($ris->num_rows === 0) {
        header("Location: http://$ip?error=credenziali_errate");
		exit();
    } else {
        $pwUtente = $ris->fetch_assoc();
        if (password_verify($password, $pwUtente['passwordUtente'])) {
            header("Location: http://$ip/_Rivellino/FrontEnd/Sito/PageHome.php");
        } else {
            header("Location: http://$ip?error=credenziali_errate");
			exit();
        }
    }

    $stmt->close();
    $conn->close();

} elseif ($azione === 'cambiaCredenziali') {
    $codice = rand(100000, 999999);
    $scadenza = date("Y-m-d H:i:s", strtotime("+10 minutes"));

    $conn = new mysqli("localhost", "root", "", "rivellino");
    if (!$conn->connect_error) {
        $stmt = $conn->prepare("INSERT INTO otp_codici (codice, scadenza) VALUES (?, ?)");
        $stmt->bind_param("ss", $codice, $scadenza);
        $stmt->execute();
        $stmt->close();
        $conn->close();
    }

    // Invio email con PHPMailer
    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'tiranti1cristian@gmail.com';
        $mail->Password   = 'nlks sfdt evkr zhhq';
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;

        $mail->setFrom('tiranti1cristian@gmail.com', 'Control Room');
        $mail->addAddress('tiranti1cristian@gmail.com');

        $mail->Subject = 'Cambio credenziali';
        $mail->Body    = "Codice OTP: $codice \n Valido fino a $scadenza";

        $mail->send();
    } catch (Exception $e) {
        echo "Errore invio email: {$mail->ErrorInfo}";
		header("Location: http://$ip?error=invio_email");
		exit();
    }

    echo '<form action="cambiaCredenziali.php" method="POST">
            <label for="codice">Inserisci il codice ricevuto via email:</label>
            <input type="text" name="codice" required>
            <button type="submit">Verifica</button>
          </form>';
} else {
    header("Location: http://$ip");
}
exit();
?>
