<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

function connessioneDB() {
    return new mysqli("localhost", "root", "", "rivellino");
}

function Login($utente, $password, $ip) {
    $conn = connessioneDB();
    if ($conn->connect_error) {
        header("Location: http://$ip?error=connessione");
        exit();
    }

    $stmt = $conn->prepare("SELECT passwordUtente FROM Utente WHERE userUtente = ?");
    $stmt->bind_param("s", $utente);
    $stmt->execute();
    $ris = $stmt->get_result();

    if ($ris->num_rows === 0) {
        header("Location: http://$ip?error=credenziali_errate");
        exit();
    }

    $pwUtente = $ris->fetch_assoc();
    if (password_verify($password, $pwUtente['passwordUtente'])) {
        header("Location: http://$ip/_Rivellino/FrontEnd/PageHome.php");
    } else {
        header("Location: http://$ip?error=credenziali_errate");
    }

    $stmt->close();
    $conn->close();
}

function ProceduraOTP($ip) {
    $codice = rand(100000, 999999);
    $scadenza = date("Y-m-d H:i:s", strtotime("+10 minutes"));

    $conn = connessioneDB();
    $stmt = $conn->prepare("INSERT INTO otp_codici (codice, scadenza) VALUES (?, ?)");
    $stmt->bind_param("ss", $codice, $scadenza);
    $stmt->execute();
    $stmt->close();
    $conn->close();

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'tiranti1cristian@gmail.com';
        $mail->Password = 'nlks sfdt evkr zhhq';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('tiranti1cristian@gmail.com', 'Control Room');
        $mail->addAddress('tiranti1cristian@gmail.com');

        $mail->Subject = 'Cambio credenziali';
        $mail->Body = "Codice OTP: $codice\nValido fino a $scadenza";

        $mail->send();
    } catch (Exception $e) {
        header("Location: http://$ip?error=invio_email");
        exit();
    }

    echo '
    <div style="max-width:400px;margin:3rem auto;padding:2rem;border:1px solid #ccc;border-radius:12px;background:#f9f9f9;">
        <h2 style="text-align:center;">Verifica OTP</h2>
        <p style="text-align:center;">Controlla la tua email. Inserisci il codice ricevuto.</p>
        <form action="_Action.php" method="POST">
            <label>Codice:</label>
            <input type="text" name="codice" style="width:100%;padding:10px;margin:10px 0;border-radius:6px;border:1px solid #aaa;" required>
            <button type="submit" name="action" value="verificaCredenziali" style="width:100%;padding:12px;margin-top:10px;background:#4CAF50;color:white;border:none;border-radius:6px;">Verifica</button>
            <button type="submit" name="action" value="annulla" formnovalidate style="width:100%;padding:12px;margin-top:10px;background:#4CAF50;color:white;border:none;border-radius:6px;">Annulla</button>
		</form>
    </div>';
}

function ValidaOTP($ip, $codice) {
    $conn = connessioneDB();
    $stmt = $conn->prepare("SELECT id, scadenza, usato FROM otp_codici WHERE codice = ? ORDER BY id DESC LIMIT 1");
    $stmt->bind_param("s", $codice);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows === 0) {
        header("Location: http://$ip?error=codice_non_valido");
        exit();
    }

    $row = $res->fetch_assoc();
    $now = date("Y-m-d H:i:s");

    if ($row['usato'] || $row['scadenza'] < $now) {
        header("Location: http://$ip?error=codice_non_valido");
        exit();
    }

    $stmt = $conn->prepare("UPDATE otp_codici SET usato = 1 WHERE id = ?");
    $stmt->bind_param("i", $row['id']);
    $stmt->execute();
    $stmt->close();
    $conn->close();

    echo '
    <div style="max-width:400px;margin:3rem auto;padding:2rem;border:1px solid #ccc;border-radius:12px;background:#f9f9f9;">
        <h2 style="text-align:center;">Cambia le credenziali</h2>
        <form action="_Action.php" method="POST">
            <input type="hidden" name="codice" value="' . htmlspecialchars($codice) . '">
            <label>Nuovo username:</label>
            <input type="text" name="nuovoUser" style="width:100%;padding:10px;margin:10px 0;border-radius:6px;border:1px solid #aaa;" required>
            <label>Nuova password:</label>
            <input type="password" name="nuovaPw" style="width:100%;padding:10px;margin:10px 0;border-radius:6px;border:1px solid #aaa;" required>
            <label>Conferma password:</label>
            <input type="password" name="confermaPw" style="width:100%;padding:10px;margin:10px 0;border-radius:6px;border:1px solid #aaa;" required>
            <button type="submit" name="action" value="modificaCredenziali" style="width:100%;padding:12px;background:#4CAF50;color:white;border:none;border-radius:6px;">Salva modifiche</button>
            <button type="submit" name="action" value="annulla" formnovalidate style="width:100%;padding:12px;margin-top:10px;background:#4CAF50;color:white;border:none;border-radius:6px;">Annulla</button>
		</form>
    </div>';
}

function CambiaCredenziali($ip, $data) {
    $nuovoUser = trim($data['nuovoUser'] ?? '');
    $nuovaPw = $data['nuovaPw'] ?? '';
    $confermaPw = $data['confermaPw'] ?? '';

    $errore = "";

    if (strlen($nuovoUser) < 4) {
        $errore = "Username troppo corto (min. 4 caratteri).";
    } elseif (strlen($nuovaPw) < 8) {
        $errore = "Password troppo corta (min. 8 caratteri).";
    } elseif ($nuovaPw !== $confermaPw) {
        $errore = "Le password non coincidono.";
    } else {
        $conn = connessioneDB();
        $query = $conn->query("SELECT passwordUtente FROM utente WHERE id = 0");
        if ($query && $query->num_rows > 0) {
            $vecchia = $query->fetch_assoc();
            if (password_verify($nuovaPw, $vecchia['passwordUtente'])) {
                $errore = "La nuova password è uguale alla precedente.";
            }
        }
    }

    if ($errore !== "") {
        echo '<div style="max-width:400px;margin:2rem auto;padding:1rem;border:1px solid #f44336;background:#ffe6e6;border-radius:8px;color:#a94442;text-align:center;">
            <strong>Errore:</strong> ' . $errore . '
        </div>';
        echo '
        <div style="max-width:400px;margin:2rem auto;padding:2rem;border:1px solid #ccc;border-radius:12px;background:#f9f9f9;">
            <h2 style="text-align:center;">Modifica le credenziali</h2>
            <form action="_Action.php" method="POST">
                <label>Nuovo username:</label>
                <input type="text" name="nuovoUser" value="' . htmlspecialchars($nuovoUser) . '" style="width:100%;padding:10px;margin:10px 0;border-radius:6px;border:1px solid #aaa;" required>
                <label>Nuova password:</label>
                <input type="password" name="nuovaPw" style="width:100%;padding:10px;margin:10px 0;border-radius:6px;border:1px solid #aaa;" required>
                <label>Conferma password:</label>
                <input type="password" name="confermaPw" style="width:100%;padding:10px;margin:10px 0;border-radius:6px;border:1px solid #aaa;" required>
                <button type="submit" name="action" value="modificaCredenziali" style="width:100%;padding:12px;background:#4CAF50;color:white;border:none;border-radius:6px;">Salva modifiche</button>
				<button type="submit" name="action" value="annulla" formnovalidate style="width:100%;padding:12px;margin-top:10px;background:#4CAF50;color:white;border:none;border-radius:6px;">Annulla</button>
			</form>
        </div>';
        return;
    }

    $conn = connessioneDB();
    $hashPw = password_hash($nuovaPw, PASSWORD_BCRYPT);
    $stmt = $conn->prepare("UPDATE utente SET userUtente = ?, passwordUtente = ? WHERE id = 0");
    $stmt->bind_param("ss", $nuovoUser, $hashPw);
    $stmt->execute();

    echo $stmt->affected_rows > 0
        ? "<p style='text-align:center;color:green;margin-top:2rem;'>Credenziali aggiornate con successo.</p>"
        : "<p style='text-align:center;color:orange;margin-top:2rem;'>Nessuna modifica effettuata.</p>";

    $stmt->close();
    $conn->close();

    header("Refresh: 2; URL=http://$ip");
    exit();
}
?>