<?php
header("Refresh: 1");

$conn = new mysqli("localhost", "root", "", "rivellino");

if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
} else {
    VisTemperature($conn);
    VisUmidita($conn);
    VisQualitaAria($conn);
    VisVibrazioni($conn);
    VisAllagamento($conn);
    VisInfoCase($conn);
}

$conn->close();


// Funzioni aggiornate: la connessione viene passata come parametro

function VisTemperature($conn) {
    echo "<hr>";
    echo "<p> Dati temperature attuale: </p>";
    echo "<ul>";

    $sensori = [
        'SensTemp1' => 'Sensore temperatura muro',
        'SensTemp2' => 'Sensore temperatura galleria',
        'SensTemp3' => 'Sensore temperatura polveriera',
    ];

    foreach ($sensori as $nomeSensore => $descrizione) {
        echo "<li> $descrizione --- ";
        $sql = "SELECT Valore FROM temperatura WHERE NameSensore = ? ORDER BY Data DESC, Ora DESC LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $nomeSensore);
        $stmt->execute();
        $ris = $stmt->get_result();

        if ($ris->num_rows == 0) {
            echo "Nessun dato presente";
        } else {
            $temp = $ris->fetch_assoc();
            echo $temp['Valore'] . "°C";
        }
        echo "</li>";

        $stmt->close();
    }

    echo "</ul>";
}

function VisUmidita($conn) {
    echo "<hr>";
    echo "<p> Dati umidità attuale: </p>";
    echo "<ul>";

    $sensori = [
        'SensUmid1' => 'Sensore umidità muro',
        'SensUmid2' => 'Sensore umidità galleria',
        'SensUmid3' => 'Sensore umidità polveriera',
    ];

    foreach ($sensori as $nomeSensore => $descrizione) {
        echo "<li> $descrizione --- ";
        $sql = "SELECT Valore FROM umidita WHERE NameSensore = ? ORDER BY Data DESC, Ora DESC LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $nomeSensore);
        $stmt->execute();
        $ris = $stmt->get_result();

        if ($ris->num_rows == 0) {
            echo "Nessun dato presente";
        } else {
            $temp = $ris->fetch_assoc();
            echo $temp['Valore'] . "%";
        }
        echo "</li>";

        $stmt->close();
    }

    echo "</ul>";
}

function VisQualitaAria($conn) {
    echo "<hr>";
    echo "<p> Dati qualità aria attuale: </p>";
    echo "<ul>";

    $sensori = [
        'SensQualitàAria1' => ['campo' => 'ValoreCo', 'descrizione' => 'Sensore Co', 'unità' => 'ppm'],
        'SensQualitàAria2' => ['campo' => 'ValoreNo2', 'descrizione' => 'Sensore No2', 'unità' => 'ppm'],
    ];

    foreach ($sensori as $nomeSensore => $info) {
        echo "<li> {$info['descrizione']} --- ";
        $sql = "SELECT {$info['campo']} FROM qualita WHERE NameSensore = ? ORDER BY Data DESC, Ora DESC LIMIT 1";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $nomeSensore);
        $stmt->execute();
        $ris = $stmt->get_result();

        if ($ris->num_rows == 0) {
            echo "Nessun dato presente";
        } else {
            $temp = $ris->fetch_assoc();
            echo $temp[$info['campo']] . $info['unità'];
        }
        echo "</li>";

        $stmt->close();
    }

    echo "</ul>";
}

function VisVibrazioni($conn) {
    echo "<hr>";
    echo "<p> Dati vibrazioni attuale: </p>";
    echo "<ul>";

    echo "<li> Sensore vibrazione --- ";
    $sql = "SELECT ValoreFrequenza, ValoreAmpiezza FROM vibrazione WHERE NameSensore = 'SensVibrazione' ORDER BY Data DESC, Ora DESC LIMIT 1";
    $ris = $conn->query($sql);

    if ($ris->num_rows == 0) {
        echo "Nessun dato presente";
    } else {
        $temp = $ris->fetch_assoc();
        echo $temp['ValoreFrequenza'] . "Hz - " . $temp['ValoreAmpiezza'] . "m/s";
    }
    echo "</li>";

    echo "</ul>";
}

function VisAllagamento($conn) {
    echo "<hr>";
    echo "<p> Dati allagamento attuale: </p>";
    echo "<ul>";

    echo "<li> Sensore allagamento --- ";
    $sql = "SELECT Valore FROM allagamento WHERE NameSensore = 'SensAllagamento' ORDER BY Data DESC, Ora DESC LIMIT 1";
    $ris = $conn->query($sql);

    if ($ris->num_rows == 0) {
        echo "Nessun dato presente";
    } else {
        $temp = $ris->fetch_assoc();
        if ($temp['Valore']) {
            echo "È stato rilevato un allagamento";
        } else {
            echo "La situazione allagamento è ok";
        }
    }
    echo "</li>";

    echo "</ul>";
}

function VisInfoCase($conn) {
    echo "<hr>";
    echo "<p> Dati case attuale: </p>";
    echo "<ul>";

    $cases = [
        'Scatola Galleria' => 'Case galleria',
        'Scatola Polveriera' => 'Case polveriera',
    ];

    foreach ($cases as $nomeScatola => $descrizione) {
        echo "<li> $descrizione --- ";
        $sql = "SELECT PercentualeBatteria FROM scatola WHERE NomeScatola = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $nomeScatola);
        $stmt->execute();
        $ris = $stmt->get_result();

        if ($ris->num_rows == 0) {
            echo "Nessun dato presente";
        } else {
            $temp = $ris->fetch_assoc();
            echo "stato batteria: " . $temp['PercentualeBatteria'] . "%";
        }
        echo "</li>";

        $stmt->close();
    }

    echo "<li> Case muro --- alimentato attraverso la rete elettrica </li>";

    echo "</ul>";
}
?>
