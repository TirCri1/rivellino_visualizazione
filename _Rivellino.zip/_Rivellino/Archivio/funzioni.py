from datetime import datetime, timedelta
import os
import pandas as pd
import logging
from config import *

logger = logging.getLogger(__name__)

def get_date_range(now):
    """
    Calcola l'intervallo di date per il mese precedente rispetto a 'now'.
    Restituisce (start, end, month, year).
    """
    year = now.year - 1
    month = now.month - 1
    if month == 0:
        month = 12
        year -= 1

    start = datetime(year, month, 1)
    end = datetime(year + 1, 1, 1) if month == 12 else datetime(year, month + 1, 1)
    return start, end, month, year

def process_table(cursor, config, start_date, end_date, month, year):
    """
    Estrae, salva su CSV e cancella i dati di una tabella per l'intervallo specificato.
    """
    table = config["tabellaQuery"]
    file_cols = config["fileStructure"]
    sensori = config["sensori"]
    output_cols = config["dbStructure"]

    query = f"""
        SELECT {', '.join(file_cols)} FROM {table}
        WHERE CONCAT(Data, ' ', Ora) >= %s AND CONCAT(Data, ' ', Ora) < %s
    """

    cursor.execute(query, (start_date, end_date))
    rows = cursor.fetchall()

    if not rows:
        logger.info(f"[{table}] Nessun dato.")
        return

    df = pd.DataFrame(rows, columns=file_cols)
    df["Data"] = pd.to_datetime(df["Data"])
    df["Ora"] = df["Ora"].apply(lambda x: (datetime.min + x).time() if isinstance(x, timedelta) else x)

    records = []
    for _, row in df.iterrows():
        for sensore in sensori:
            if table == "temperatura":
                if row["Valore"] <= 1 or row["Valore"] >= 25:
                    records.append([row["Data"].day, row["Ora"], row["Valore"], sensore])
            elif table == "umidita":
                if row["Valore"] <= 40 or row["Valore"] >= 75:
                    records.append([row["Data"].day, row["Ora"], row["Valore"], sensore])
            elif table == "qualita":
                if row["ValoreCo"] >= 50 or row["ValoreNo2"] >= 30:
                    records.append([row["Data"].day, row["Ora"], row["ValoreCo"], row["ValoreNo2"], sensore])
            elif table == "vibrazione":
                records.append([row["Data"].day, row["Ora"], row["ValoreFrequenza"], row["ValoreAmpiezza"], sensore])
            elif table == "allagamento":
                records.append([row["Data"].day, row["Ora"], row["Valore"], sensore])

    if not records:
        logger.info(f"[{table}] Nessun dato da salvare per il periodo selezionato.")
        return

    output_df = pd.DataFrame(records, columns=output_cols)
    year_folder = os.path.join(PATH, f"dati_{year}")
    os.makedirs(year_folder, exist_ok=True)
    filename = os.path.join(year_folder, f"{config['file'].split('.')[0]}_{str(month).zfill(2)}.csv")
    output_df.to_csv(filename, index=False)
    logger.info(f"[{table}] Salvato: {filename}")

    delete_query = f"""
        DELETE FROM {table}
        WHERE CONCAT(Data, ' ', Ora) >= %s AND CONCAT(Data, ' ', Ora) < %s
    """
    cursor.execute(delete_query, (start_date, end_date))
    logger.info(f"[{table}] Dati vecchi eliminati dal database.")