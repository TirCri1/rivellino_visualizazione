
#Configurazioni


#Token del bot
TOKEN = '7903372067:AAEhRKtv0YzKnc5o2BRaElduv5lNxw3HuzY'
#ID della chat
CHAT_ID = '-1002647520150'

#Configurazioni del DB
DB_CONFIG = {
    "host": "localhost",
    #"host": "10.10.60.186",
    "user": "remoteUser",
    "password": "!rivellino!RIVELLINO!",
    "database": "rivellino"
}

#Fequnza di controllo
interval = { # secondi
    "allag": 10,
    "batt": 10,
    "vibr": 1,
    "resend": 60 #interval resend message
}

FILE_MESSAGES = 'Avvisi/Messages.json'