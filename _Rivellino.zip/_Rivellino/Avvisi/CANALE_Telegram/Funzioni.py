import requests
import mysql.connector
import json
import os
import logging

from Config import *  # Importa le variabili di configurazione

logger = logging.getLogger(__name__)

def connect_db():
    """Restituisce una connessione al database MySQL, logga eventuali errori."""
    try:
        return mysql.connector.connect(**DB_CONFIG)
    except mysql.connector.Error as err:
        logger.error(f"[ERRORE DB] {err}")
        return None

def send_message(token, chat_id, text):
    """Invia un messaggio via Telegram e salva l'ID del messaggio se inviato con successo."""
    url = f'https://api.telegram.org/bot{token}/sendMessage'
    payload = {
        'chat_id': chat_id,
        'text': text,
        'parse_mode': 'HTML'
    }
    try:
        response = requests.post(url, data=payload)
        res_json = response.json()
        if 'result' in res_json:
            message_id = res_json['result']['message_id']
            save_message_id(message_id)
            return res_json
        else:
            logger.error(f"Errore nell'invio del messaggio: {res_json}")
            return res_json
    except Exception as e:
        logger.error(f"Eccezione durante l'invio del messaggio: {e}")
        return None

def save_message_id(message_id):
    """Salva l'ID dei messaggi inviati nella chat in un file JSON."""
    try:
        if os.path.exists(FILE_MESSAGES):
            with open(FILE_MESSAGES, 'r') as f:
                data = json.load(f)
        else:
            data = []

        if message_id not in data:
            data.append(message_id)
            with open(FILE_MESSAGES, 'w') as f:
                json.dump(data, f)
    except Exception as e:
        logger.warning(f"Impossibile salvare message_id {message_id}: {e}")

def verifica(tipo, events, message, last):
    """
    Verifica eventi critici: allagamento, batteria scarica, vibrazione.
    Aggiorna gli array events e message in base alle condizioni rilevate.
    """
    event = False
    conn = connect_db()
    if not conn:
        return
    cursor = conn.cursor()

    try:
        # Verifica Allagamento
        if tipo == "allag":
            query = """
                SELECT *
                FROM allagamento
                WHERE NameSensore = 'SensAllagamento'
                ORDER BY Data DESC, Ora DESC
                LIMIT 1
            """
            cursor.execute(query)
            row = cursor.fetchone()
            if row:
                date, hour, val = row[0], row[1], bool(row[2])
                timestamp_event = f"{date} {hour}"
                if timestamp_event != last[0]:
                    event = val
                    last[0] = timestamp_event
                if event:
                    MESSAGE = (
                        f"🚨💧 <b>ALLERTA ALLAGAMENTO</b>\n"
                        f"📅 Data: <i>{date}</i>\n"
                        f"🕒 Ora: <i>{hour}</i>"
                    )
                    message[0] = MESSAGE
                    events[0] = True
            else:
                logger.info("Nessun dato allagamento trovato.")

        # Verifica Batterie
        if tipo == "batt":
            query = """
                SELECT *
                FROM scatola
                WHERE NomeScatola = 'Scatola Galleria' OR NomeScatola = 'Scatola Polveriera'
            """
            cursor.execute(query)
            results = cursor.fetchall()
            if results and len(results) >= 2:
                sG = ""
                sP = ""
                valGalleria = results[0][1]
                valPolveriera = results[1][1]

                if valGalleria < 10:
                    if valGalleria != last[1]:
                        event = True
                        sG = " galleria"
                        last[1] = valGalleria
                else:
                    last[1] = None

                if valPolveriera < 10:
                    if valPolveriera != last[2]:
                        event = True
                        sP = " polveriera"
                        last[2] = valPolveriera
                else:
                    last[2] = None

                if event:
                    MESSAGE = (
                        f"🚨🪫 <b>BATTERIA SCARICA</b>\n"
                        f"🧰 Case interessate:{sG}{sP}\n"
                        f"⚠️ È necessaria la sostituzione"
                    )
                    message[1] = MESSAGE
                    events[1] = True
            else:
                logger.info("Nessun dato batteria trovato.")

        # Verifica Vibrazione
        if tipo == "vibr":
            query = """
                SELECT Data, Ora
                FROM vibrazione
                WHERE NameSensore = 'SensVibrazione'
                ORDER BY Data DESC, Ora DESC
                LIMIT 1
            """
            cursor.execute(query)
            row = cursor.fetchone()
            if row:
                date, hour = row[0], row[1]
                timestamp_event = f"{date} {hour}"
                if timestamp_event != last[3]:
                    event = True
                    last[3] = timestamp_event
                if event:
                    MESSAGE = (
                        f"🚨📡 <b>ALLERTA VIBRAZIONE RILEVATA</b>\n"
                        f"📅 Data: <i>{date}</i>\n"
                        f"🕒 Ora: <i>{hour}</i>"
                    )
                    message[2] = MESSAGE
                    events[2] = True
            else:
                logger.info("Nessun dato vibrazione trovato.")

    except Exception as e:
        logger.error(f"[ERRORE verifica] - {e}")
    finally:
        cursor.close()
        conn.close()