import logging
import signal
from datetime import datetime
from time import sleep
import calendar

from Funzioni import *
from config import *

LOG_FILE = "report_email.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, mode='a'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

stop = False
test = True  # Imposta a False per produzione

def dati_validi(valori):
    """Controlla che i dati siano validi per la generazione del report."""
    return all(v and len(v) == 3 and "Nessun dato" not in v for v in valori[:4])

def signal_handler(sig, frame):
    logger.info("🛑 Interruzione ricevuta. Uscita dal programma.")
    exit(0)

def main():
    logger.info("Avvio monitoraggio per generazione report mensile (Ctrl + C per uscire)...")
    global stop

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    try:
        while True:
            now = datetime(2026, 6, 1, 0, 0) if test else datetime.now()
            mese = now.month
            giorno = now.day

            if giorno == 1 and not stop:
                logger.info(f"Creazione del report per {calendar.month_name[mese]} ed invio tramite mail...")

                try:
                    val = datiRep(mese)
                    if val and dati_validi(val):
                        percorso_allegato = report(val, mese)
                        sendemail(mittente, destinatario, oggetto, contenuto, percorso_allegato)
                        logger.info("✅ Report mensile inviato con successo.")
                        stop = True
                    else:
                        logger.warning("⚠️ Dati insufficienti per generare il report.")
                except Exception as e:
                    logger.error(f"❌ Errore durante il processo: {e}")

            if giorno != 1:
                stop = False  # Reset quando non è il primo giorno del mese

            if test:
                break  # Uscita immediata in test

            sleep(3600)

    except KeyboardInterrupt:
        logger.info("⏹ Interrotto manualmente. Uscita dal programma.")

if __name__ == '__main__':
    main()