
#Configurazioni


#Token del bot
TOKEN = '7903372067:AAEhRKtv0YzKnc5o2BRaElduv5lNxw3HuzY'
#ID della chat
CHAT_ID = '-1002647520150'

USERNAME_CORRETTO = "Rivellino"
PASSWORD_CORRETTA = "Allert"
USERNAME_ADMIN = "RivellinoAdmin"
PASSWORD_ADMIN = "AllertAdmin"
LINK_CANALI_PRIVATO = "https://t.me/+Eftu5Y1i9ftjN2Nk"
CLEANUP_DELAY_SECONDS_EXIT = 1
CLEANUP_DELAY_SECONDS_CHAT = 10
CLEANUP_DELAY_SECONDS_ERROR = 1

MESSAGES_FILE = 'Avvisi/Messages.json'