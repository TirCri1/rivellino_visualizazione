import signal
import sys
import logging
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters

from Config import *  # contiene TOKEN, ecc.
from Funzioni import *  # contiene funzioni come start e gestisci_messaggi

# --- CONFIGURAZIONE LOGGING ---
LOG_FILE = "bot_telegram.log"
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, mode='a'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

def stop_bot(signum, frame):
    """Gestore per la chiusura pulita del bot tramite segnali."""
    logger.info("🛑 Interruzione ricevuta. Il bot si sta chiudendo...")
    sys.exit(0)

def main():
    """Avvia il bot Telegram e gestisce i segnali di terminazione."""
    signal.signal(signal.SIGINT, stop_bot)
    signal.signal(signal.SIGTERM, stop_bot)

    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, gestisci_messaggi))

    logger.info("🤖 Bot avviato. Premi Ctrl+C per terminare.")
    app.run_polling()

if __name__ == "__main__":
    main()