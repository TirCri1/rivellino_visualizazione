import os
import pandas as pd
import mysql.connector.pooling
from datetime import datetime
import logging
from config import DB_CONFIG, STRUCTURE

logger = logging.getLogger(__name__)

# Connection pool globale
db_pool = mysql.connector.pooling.MySQLConnectionPool(
    pool_name="mypool",
    pool_size=10,
    **DB_CONFIG
)

# Cache per timestamp dei file letti
_last_file_timestamps = {}

def connect_db():
    """Restituisce una connessione dal pool, logga eventuali errori."""
    try:
        return db_pool.get_connection()
    except mysql.connector.Error as err:
        logger.error(f"[ERRORE DB POOL] {err}")
        return None

def read_file(structure):
    """
    Legge il file CSV relativo al sensore.
    Ritorna un DataFrame ordinato dal più recente.
    """
    path = structure["filePath"]
    try:
        mtime = os.path.getmtime(path)
        if _last_file_timestamps.get(path) == mtime:
            return pd.DataFrame()
        _last_file_timestamps[path] = mtime

        df = pd.read_csv(path, sep=',', encoding='latin1')
        df.columns = structure["fileStructure"]
        return df[::-1].reset_index(drop=True)
    except FileNotFoundError:
        logger.warning(f"[ERRORE] File non trovato: {path}")
    except Exception as e:
        logger.error(f"[ERRORE LETTURA FILE] {path} - {e}")
    return pd.DataFrame()

def sql_check(structure):
    """Query per controllare se il dato è già presente."""
    table = structure["tabellaQuery"]
    return f"""
        SELECT 1 FROM {table} WHERE NameSensore = %s AND Data = %s AND Ora = %s
    """

def sql_insert(structure):
    """Query di inserimento dati."""
    table = structure["tabellaQuery"]
    columns = structure["dbStructure"]
    placeholders = ", ".join(["%s"] * len(columns))
    return f"INSERT INTO {table} ({', '.join(columns)}) VALUES ({placeholders})"

def insert(sensor_type):
    """
    Inserisce i dati dal file CSV nel database per il tipo di sensore specificato.
    """
    structure = STRUCTURE[sensor_type]
    df = read_file(structure)
    if df.empty:
        return

    conn = connect_db()
    if not conn:
        return

    try:
        with conn.cursor() as cursor:
            for _, row in df.iterrows():
                try:
                    timestamp = datetime.strptime(row['timestamp'], '%Y-%m-%d %H:%M:%S')
                except ValueError:
                    logger.warning(f"[ERRORE DATA] Formato non valido: {row}")
                    continue

                case = row['modulo']
                case_data = structure.get("sensori", {}).get(case)
                if not case_data:
                    continue

                for sensor_name, value_info in case_data.items():
                    cursor.execute(sql_check(structure), (sensor_name, timestamp.date(), timestamp.time()))
                    if cursor.fetchone():
                        continue

                    query = sql_insert(structure)
                    if sensor_type == "vibrazione":
                        freq = row.get("frequenza")
                        amp = float(row.get("vibrazione"))
                        cursor.execute(query, (timestamp.date(), timestamp.time(), freq, amp, sensor_name))
                    elif sensor_type == "ariaCO":
                        co = row.get("CO")
                        cursor.execute(query, (timestamp.date(), timestamp.time(), co, -1, sensor_name))
                    elif sensor_type == "ariaNO2":
                        no2 = row.get("NO2")
                        cursor.execute(query, (timestamp.date(), timestamp.time(), -1, no2, sensor_name))
                    else:
                        value = row.get(value_info)
                        cursor.execute(query, (timestamp.date(), timestamp.time(), value, sensor_name))

                    logger.info(f"Inserito {sensor_type}: {sensor_name} - {timestamp}")
            conn.commit()
    except Exception as e:
        logger.error(f"[ERRORE INSERIMENTO] {sensor_type} - {e}")
    finally:
        conn.close()

def update_battery_charger(sensor_type):
    """
    Aggiorna lo stato della batteria nel database per il tipo di sensore 'alimentazione'.
    """
    structure = STRUCTURE[sensor_type]
    df = read_file(structure)
    if df.empty:
        return

    conn = connect_db()
    if not conn:
        return

    try:
        with conn.cursor() as cursor:
            for key, sensor_dict in structure["sensori"].items():
                for scatola, colonna in sensor_dict.items():
                    row = df[df['modulo'] == key]
                    if row.empty:
                        continue

                    last_row = row.iloc[0]
                    valore = last_row.get(colonna)
                    if valore is None:
                        continue

                    query = f"""
                        UPDATE {structure['tabellaQuery']} SET {structure['dbStructure'][1]} = %s
                        WHERE {structure['dbStructure'][0]} = %s
                    """
                    cursor.execute(query, (int(valore), scatola))
                    logger.info(f"Aggiornata batteria {scatola}: {valore}%")

            conn.commit()
    except Exception as e:
        logger.error(f"[ERRORE BATTERIA] - {e}")
    finally:
        conn.close()